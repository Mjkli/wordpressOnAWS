<?php

// Don't redefine the functions if included multiple times.
if (!function_exists('GuzzleHttp\describe_type')) {
    require __DIR__ . '/functions.php';
}
